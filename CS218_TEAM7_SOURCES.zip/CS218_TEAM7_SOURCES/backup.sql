-- MySQL dump 10.16  Distrib 10.2.10-MariaDB, for Linux (x86_64)
--
-- Host: ecommerce-website-cs218.cik1iws04xen.us-east-1.rds.amazonaws.com    Database: ecommerce
-- ------------------------------------------------------
-- Server version       5.6.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `model` varchar(200) NOT NULL,
  `type` varchar(60) NOT NULL,
  `price` double NOT NULL,
  `details` text NOT NULL,
  `image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Samsung','Galaxy S3',457.9,'2 year warranty, Rating : 4/5','http://d2h6qiygz71y88.cloudfront.net/WhatsApp+Image+2019-05-01+at+11.41.38+AM.jpeg'),(2,'Apple','IPad Mini',499.9,'1 year warranty, Rating : 4.5/5','http://d2h6qiygz71y88.cloudfront.net/WhatsApp+Image+2019-05-01+at+11.41.39+AM.jpeg'),(3,'Dell','Inspiron 1500',1000,'2 years warranty, Rating : 4/5','http://d2h6qiygz71y88.cloudfront.net/WhatsApp+Image+2019-05-01+at+11.41.39+AM+(1).jpeg');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testtable`
--

DROP TABLE IF EXISTS `testtable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testtable` (
  `uid` int(11) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testtable`
--

LOCK TABLES `testtable` WRITE;
/*!40000 ALTER TABLE `testtable` DISABLE KEYS */;
INSERT INTO `testtable` VALUES (1,'Ashrit');
/*!40000 ALTER TABLE `testtable` ENABLE KEYS */;
UNLOCK TABLES;


--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (0,'riti','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'root','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'ashrit','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'root45','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'Ashritdeebadi','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'ritig','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'cs218','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'dashrit','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'veda123','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'Vedashree Bhandare','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'rootuser','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'sasank','$2y$10$qf0keVOMHWXzSaEkEHlA1u9Xbhs1GOGRR3fI3Bk3ezI0MygLmSnTK'),(0,'pragya','$2y$10$sy.YcPSZvoXkfK3I04CIv.3dmW6L/4OCnKFNEuLxY4jW8ZQ09u0bK');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-05 22:58:12
