<?php
session_start();
require_once "config.php";
if($_SERVER["REQUEST_METHOD"] == "POST"){
        $query = "SELECT model FROM products";
        $result = mysqli_query($conn,$query);
        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
        $m1 = $row['model'];
        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
        $m2 = $row['model'];
        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
        $m3 = $row['model'];
        $subject = "Marketing Emails";
        $body="Our new products available of latest brands like ".$m1 . "," . $m2 . " and ". $m3;
        mail($_POST["email"],$subject,$body);
        echo("Mails Sent!!!\n\n\n");
}
?>

<html>
<body>
    <div class="wrapper">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label>Email</label>
            <input type="text" name="email" class="form-control" value=""><br><br>
            <button type="submit" class="btn btn-primary">Send mails</button>
        </form>
    </div>
</body>
</html>
