<?php
    session_start();
    require_once "config.php";
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $pid = $_GET['id'];
        $query = "SELECT * FROM products where id='$pid'";
        $result = mysqli_query($conn,$query);
        $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
        $subject = "Purchase Details";
        $body="You purchased " . $row['model'] . " " .$row['type'] . " for " . $row['price'] . " dollars.\nIt will be delivered by tomorrow.";
        mail($_POST["email"],$subject,$body);
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
        <style type="text/css">
            body{ font: 14px sans-serif; }
            .wrapper{ width: 350px; padding: 20px; }
        </style>
    </head>
    <body>
        <div class="wrapper">
            <label>Credit Card</label>
            <input type="text" name="credit card" class="form-control" value=""><br><br>
        </div>
        <br><br>
        <div class="wrapper">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>?id=<?php echo $_GET['id'];?>" method="post">
            <label>Email</label>
            <input type="text" name="email" class="form-control" value=""><br><br>
            <button type="submit" class="btn btn-primary">Send mail</button>
            </form>
        </div>
    </body>
</html>
