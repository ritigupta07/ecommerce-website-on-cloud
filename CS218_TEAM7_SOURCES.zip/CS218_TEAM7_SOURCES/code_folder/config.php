<?php
define('DB_SERVER', 'ecommerce-website-cs218.cik1iws04xen.us-east-1.rds.amazonaws.com');
define('DB_USERNAME', 'masteruser');
define('DB_PASSWORD', 'Masteruser_123');
define('DB_NAME', 'ecommerce');

$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

if($conn === false){
    die("Error in connecting." . mysqli_connect_error());
}
?>
