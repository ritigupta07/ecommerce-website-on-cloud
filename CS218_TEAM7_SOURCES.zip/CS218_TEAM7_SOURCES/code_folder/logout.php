<?php
session_start();

// Clear and destroy the session
$_SESSION = array();
session_destroy();

// Redirect to login page
header("location: index.php");
exit;
?>
