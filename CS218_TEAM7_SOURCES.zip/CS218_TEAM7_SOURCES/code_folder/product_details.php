<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if(!(isset($_SESSION["login"]) && $_SESSION["login"] === true)){
    exit;
}

// Include config file
require_once "config.php";
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  width: 50%;
  padding: 10px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
</head>
<body>

<h2 style="text-align:center">Details</h2>

<div class="card">
<?php
$pid = $_GET['id'];
$query = "SELECT * FROM products where id='$pid'";
$result = mysqli_query($conn,$query);
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
?>
<img src="<?php echo $row['image'];?>" alt="Test..." style="width:500px;height:300px;">
<br>
<br>
<?php
printf ("Model : %s",$row['model']);
?>
<br>
<?php
printf ("Type : %s",$row['type']);
?>
<br>
<?php
printf ("Price : %s Dollars\n", $row['price']);
?>
<br>
<?php
printf ("Details : %s",$row['details']);
?>
</div>
<br><br>
    <center><a href="checkout.php?id=<?php echo $row['id'];?>" class="btn btn-primary">Checkout</a></center>
<br><br>
</body>
</html>
