<?php
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page
if(!(isset($_SESSION["login"]) && $_SESSION["login"] === true)){
    exit;
}

// Include config file
require_once "config.php";
?>

<!DOCTYPE html>
<html>
<head>
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  width:50%;
  padding:10px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.price {
  color: grey;
  font-size: 22px;
}

.card button {
  border: none;
  outline: 0;
  padding: 12px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

.card button:hover {
  opacity: 0.7;
}
</style>
</head>
<body>

<h2 style="text-align:center">Products</h2>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <select name="modelselector" style="margin-left:40px; font-size:14px;">
        <option value="Samsung">Samsung</option>
        <option value="Apple">Apple</option>
        <option value="Dell">Dell</option>
    </select>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>

<?php
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $model = $_POST["modelselector"];
    $result = mysqli_query($conn,"SELECT * FROM products where model='$model'");
} else {
    $result = mysqli_query($conn,"SELECT * FROM products");
}
?>

<div class="card">
<?php
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
?>
<a href="product_details.php?id=<?php echo $row['id'];?>">
<img src="<?php echo $row['image'];?>" alt="Test..." style="width:500px;height:300px;">
</a>
<br>
<?php
printf ("Model : %s",$row['model']);
?>
<br>
<?php
printf ("Type : %s",$row['type']);
?>
<br>
<?php
printf ("Price : %s Dollars",$row['price']);
?>
</div>
<br><br><br><br><br>
<?php if(mysqli_num_rows($result)>1) {?>

<div class="card">
<?php
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
?>
<a href="product_details.php?id=<?php echo $row['id'];?>">
<img src="<?php echo $row['image'];?>" alt="Test..." style="width:500px;height:300px;">
</a>
<br>
<?php
printf ("Model : %s",$row['model']);
?>
<br>
<?php
printf ("Type : %s",$row['type']);
?>
<br>
<?php
printf ("Price : %s Dollars",$row['price']);
?>
</div>

<br><br><br><br><br>

<div class="card">
<?php
$row=mysqli_fetch_array($result,MYSQLI_ASSOC);
?>
<a href="product_details.php?id=<?php echo $row['id'];?>">
<img src="<?php echo $row['image'];?>" alt="Test..." style="width:500px;height:300px;">
</a>
<br>
<?php
printf ("Model : %s",$row['model']);
?>
<br>
<?php
printf ("Type : %s",$row['type']);
?>
<br>
<?php
printf ("Price : %s Dollars",$row['price']);
?>
</div>
<?php }?>
<br><br><br><br><br>
</body>
</html>
