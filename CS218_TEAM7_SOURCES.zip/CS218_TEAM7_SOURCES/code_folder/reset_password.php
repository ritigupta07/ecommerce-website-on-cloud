<?php
session_start();

if(!isset($_SESSION["login"]) || $_SESSION["login"] !== true){
    header("location: index.php");
    exit;
}
require_once "config.php";

// Variable initialization 
$new_pwd = $confirm_pwd = "";
$new_pwd_err = $confirm_pwd_err = "";

// Operations to be executed on submitting the form
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate new password
    if(empty(trim($_POST["new_pwd"]))){
        $new_pwd_err = "Enter new password to be set.";
    } elseif(strlen(trim($_POST["new_pwd"])) < 6){
        $new_pwd_err = "Password must have atleast 6 characters.";
    } else{
        $new_pwd = trim($_POST["new_pwd"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["confirm_pwd"]))){
        $confirm_pwd_err = "Please confirm the password.";
    } else{
        $confirm_pwd = trim($_POST["confirm_pwd"]);
        if(empty($new_pwd_err) && ($new_pwd != $confirm_pwd)){
            $confirm_pwd_err = "Sorrry...Password did not match.";
        }
    }

    // Check input errors before updating the database
    if(empty($new_pwd_err) && empty($confirm_pwd_err)){
        // Prepare an update statement
        $sql = "UPDATE users SET password = ? WHERE id = ?";
    if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "si", $param_password, $param_id);

            // Set parameters
            $param_password = password_hash($new_pwd, PASSWORD_DEFAULT);
            $param_id = $_SESSION["id"];

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Password updated successfully. Destroy the session, and redirect to login page
                session_destroy();
                header("location: index.php");
                exit();
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
        <h2>Reset Password</h2>
        <p>Please enter below details to reset your password.</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group <?php echo (!empty($new_pwd_err)) ? 'has-error' : ''; ?>">
                <label>New Password</label>
                <input type="password" name="new_pwd" class="form-control" value="<?php echo $new_pwd; ?>">
                <span class="help-block"><?php echo $new_pwd_err; ?></span>
            </div>
            <div class="form-group <?php echo (!empty($confirm_pwd_err)) ? 'has-error' : ''; ?>">
                <label>Confirm Password</label>
                <input type="password" name="confirm_pwd" class="form-control">
                <span class="help-block"><?php echo $confirm_pwd_err; ?></span>
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-primary" value="Submit">
                <a class="btn btn-link" href="welcome.php">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
